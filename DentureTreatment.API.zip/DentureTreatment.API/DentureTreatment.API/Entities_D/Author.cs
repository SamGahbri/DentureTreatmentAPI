﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace DentureTreatment.API.Entities_D;


    [Table("Clinical_Dental_Technician")]

    public class Author
    {
    [Key]
    
    public Guid Id { get; set; }

    [Required]
    [MaxLength(150)]

    public string FirstName { get; set; }
    [Required]
    [MaxLength(150)]

    public string LastName { get; set; }


    public Author(Guid id, string firstname, string lastname)
    {
        Id = id;
        FirstName = firstname;
        LastName = lastname;
    }

}

